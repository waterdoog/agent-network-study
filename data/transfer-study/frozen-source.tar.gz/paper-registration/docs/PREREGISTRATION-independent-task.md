# Prospective independent-task extension: 8 October 2026

## Status and scope

This is a new, budget-limited transfer study designed after inspecting Studies
1--8. It does not amend, extend the sample of, or replace any of the five
registered Astra tests. In particular, Study 8 R4 remains reported with its
original sample, interval and support criterion. This extension asks whether
the exchange-policy effect transfers from fixed-content web tasks to fresh
structured decision instances. It is not a new-algorithm evaluation or a test
of directory-token cost.

The protocol must be committed and pushed to the paper repository's main
branch before any extension smoke or formal model call. Its registration
commit is the timestamp. Implementation tests before registration use only
deterministic examples and mocked transport, not model responses. The source
revision and hashes are recorded below.

## Model and transport

- Fixed model: `gpt-6-astra`, via the same ChatGPT subscription Responses
  transport as Study 8. No API key, model fallback or purchased quota.
- Service-default sampling; `reasoning.effort=medium`; no temperature request.
- Requester: at most 8 calls, each with `max_output_tokens=3000`, including
  reasoning. Holder: at most 900 output tokens per answer.
- Import the existing `src/lib/subscription.js` transport without changing it.
  Each successful call must report the upstream model as `gpt-6-astra` and
  verifiable usage. Record full parsed model messages, tool inputs/outputs, response
  identifiers, request/output hashes, serving identity and token usage.
  Original SSE wire bytes are not retained by the unchanged adapter.
- USD cost is unavailable when the subscription ledger reports null. Tokens
  are reported separately; no API pricing is substituted for actual billing.

## Task generator and exact reference solution

Each world contains 8 projects. Select at most 3 to maximize total benefit
under both a funding and a work-hours limit and one mutual-exclusion pair.
Selecting both projects of a separate synergy pair adds a bonus.

- Per-project cost: uniform integer 2--9; hours: 1--7; base benefit: 4--20.
- Funding limit: floor(0.35 times the sum of all project costs).
- Hours limit: floor(0.40 times the sum of all project hours).
- The exclusion pair is drawn uniformly from the 28 unordered project pairs.
  The synergy pair is drawn from the remaining 27; its bonus is uniform
  integer 5--12. A pair cannot have both roles.
- A fixed mulberry32 generator, initialized from the first little-endian
  32 bits of SHA-256(`portfolio-transfer-v1:<seed>`), produces the facts and
  seed-specific project and holder ordering. There is no instance filtering by policy outcomes or
  difficulty, nor any difficulty change after smoke.
- Three holders possess, respectively, costs; hours and exclusion; benefits
  and synergy. The assignment of these domains to holder IDs is shuffled.
  Every holder is visible and reachable, with accurately labelled domains.
- The requester initially sees project IDs, budgets, the maximum selection
  size, the rules of the decision problem and the holder directory. It does
  not see private values, pair identities or the bonus.
- Enumerate all 256 subsets to obtain exact feasible utility and the optimum.
  The empty set is feasible with value 0; generated worlds have a positive
  optimum. All tied optimal selections are accepted.

The generated facts and reference solutions are saved before the calls. Their
world/answer-key hashes distinguish new factual instances from repetitions of
the previous three web templates. There is no HTML, builder or text-substring
scorer in this extension.

## Arms and budgets

`strict` retains the earlier composite restrictive exchange policy: the
requester asks specific questions and holders answer what was asked without
volunteering other values. `permissive` allows the requester to ask broadly
for task-relevant information and holders to volunteer relevant held facts.
Neither arm has direct store/list/read tools. Strict holders may answer a
specific question that explicitly requests all values of a named field;
the intervention does not mechanically enforce one fact per answer.

Both arms use the same worlds, task instructions except for the policy text,
tool schemas, limits and response wrappers. The intervention still changes
requester and holder instructions together; it does not isolate either prompt.
Each holder call is stateless: it receives its fixed facts and the current
question, without earlier requester or holder conversation history.

Tools are `ask_agent` and `submit_selection`. At most 6 holder questions may
be executed per episode. Multiple calls in one requester response count
separately towards that limit. Requester call 8 exposes submission only.
All holder responses use the same text response wrapper; no arm returns a
different artifact representation. The first parseable submission ends the
episode and receives no correctness feedback or revision opportunity.
Malformed calls receive the same fixed error handling in all arms, within
the same budgets; they are model behavior rather than technical reruns.
In particular, a parseable submission with an invalid/missing selection,
unknown or duplicate IDs, or an infeasible set ends the episode and scores
zero; it is not returned as a correctable schema error.

`full_information` is a descriptive diagnostic on 12 prespecified worlds:
the requester receives all true facts, has the same 8-call/3000-token-per-call
requester limits, and has only `submit_selection`. It normally submits at
once; it does not receive score feedback. It diagnoses performance when facts
are supplied, not a token-matched algorithm baseline or a causal mediation
estimate.

## Fixed sample and order

- Formal worlds: seeds 1001--1048 inclusive, paired `strict` and `permissive`:
  48 independent generated worlds and 96 formal comparison episodes.
- Diagnostic worlds: 1001, 1005, 1009, 1013, 1017, 1021, 1025, 1029, 1033,
  1037, 1041, 1045: 12 `full_information` episodes. Formal total: 108.
- Smoke: worlds 1 and 2, all three arms, 6 episodes; never pooled with the
  formal sample. The gate checks transport, serving identity, saved records
  and scorer execution, not whether either policy succeeds or wins.
- Shuffle formal episodes with fixed order seed 20261008; initial concurrency
  6, any permitted technical rerun concurrency 2. Order is saved in the run
  manifest before the first call and preserved on resume.
- N=48 is a fixed resource-limited sample, not a claimed power guarantee.
  For illustration, a paired-difference SD of 0.25 would give an approximate
  95% mean interval half-width of 0.071; the actual variability is unknown.
  This design is not powered to exclude a small effect such as 0.016.
- No outcome-based expansion, early success stopping, task replacement or
  selection of favorable seeds/arms. No contrasts or quality summaries are
  inspected until all planned episodes have final attempt statuses.

## Outcomes and analysis

The primary outcome is feasible normalized utility: the actual selected-set
benefit divided by the exact optimum if all constraints are met, otherwise 0.
Unknown or duplicate IDs, an overlarge or infeasible set, and no submission
within the fixed budget score 0. These are model outcomes, not technical
failures. Empty selection scores 0. A reported utility number is ignored;
utility is computed from the saved world and submitted project IDs.

There is one primary contrast: mean within-world `permissive - strict`
normalized utility over all 48 pairs, including model failures as zero.
Report a two-sided 95% percentile paired bootstrap interval (10,000 resamples,
seed 20261008) and a two-sided Monte Carlo sign-flip p-value (100,000 draws,
seed 20261009, plus-one correction). The latter is not an exhaustive exact
test. It uses T = abs(mean(d)) and
p = (1 + count(abs(mean(s*d)) >= T)) / 100001, with independent equiprobable
signs per world and draw. Its null assumes within-world exchangeability of
the two policy outcomes (no policy effect on their conditional distribution);
it is not a distribution-free test of an arbitrary zero-average-effect null.
The implementation includes a 1e-12 tolerance when comparing statistics to
count numerically equal floating-point values as ties.
Positive transfer is supported only if the interval's lower bound is
above 0 and p < 0.05. There is one primary test, so no multiplicity correction
is applied to it. Exact-zero/non-significant estimates do not prove equivalence.

A +0.10 normalized-utility difference is the prespecified practical reference.
Report the estimate and interval relative to this reference; a point estimate
above 0.10 alone does not establish an effect of at least that size. This scale
is task-specific and is not numerically pooled with requirement F1.

Secondary/descriptive outputs, all reported regardless of the primary result:
exact-optimal rate, feasibility, submission rate, tokens, question counts,
per-world paired outcomes, and full-information outcomes on the fixed subset.
No significance claims are generated by selecting these secondary outcomes.
Describe diagnostic performance and its limits; it does not itself identify
information withholding or planning as a causal mechanism.

## Failures, serving and reproducibility

Transient transport behavior follows the unchanged subscription transport
(up to 5 attempts per call for its retryable conditions). An episode with a
genuine transport/crash/scorer technical failure is set aside intact and rerun
once with identical settings. Model non-submission, bad calls, infeasibility
and a completed response truncated by the output limit are not technical
failures. A wrong or missing served identity is an exclusion and a stop signal,
never silently replaced with a different model.

A newly executed HTTP 401 authentication failure pauses the sweep before
immediate rerun. Resume manually only after restoring the normal Codex login.
Its original failed attempt is retained and consumes the original attempt;
only the single registered technical rerun remains. A new 401 on that rerun
pauses again and is then finalized as technical exhaustion on manual resume,
without a third attempt. Interrupted concurrent attempts are preserved and
explicitly marked technical before resume. No credential is printed or archived.

Resumption skips saved final summaries and must not create a second technical
rerun. If a comparison episode still has a technical failure after its one
rerun, report the collection as incomplete and do not claim a confirmatory
48-pair result; technical failure is not converted to model utility zero.
Unresolved diagnostic failures are reported separately. No primary comparison
is computed before the planned attempts, including allowed reruns, conclude.

An anonymous archive will include the frozen generator and prompts, reference
solver/scorer, worlds and answers, per-attempt records, final summaries,
analysis code/results, this protocol and a file manifest with checksums.
Credentials and raw login configuration are never written into the archive.
Original Study 8 data/tests remain intact. The paper must report the result
and scope of this extension even if it fails to support transfer.

## AI-assisted design provenance

This extension follows the author's request to implement the independent-task
validation discussed during an author-side AI review. OpenAI Codex assistants
helped propose the project-selection task, audit its solver, implement the
transport wrapper and analyze results. The exact assistant snapshot is not
available in the retained interface metadata. The experimental model is
separately fixed and checked as `gpt-6-astra`. Relevant retained instruction
excerpts and source versions will be included with the final supplement.

## Frozen implementation reference

- Source repository: https://github.com/waterdoog/agent-network-study
- Frozen source revision: `cec9631550af39e7c0f8435bb6908c4eff41c1d2`.
- Directory: `scripts/transfer-study/`; source manifest:
  `scripts/transfer-study/source-manifest.json`.
- Manifest file SHA-256:
  `e0af54ac34ae8f86cf8fb1ffffba3ed07cae18c3f8a4e46e10a980d8b79cd388`.
- The manifest hashes the generator, prompts/engine, runner, controller,
  worker, scorer, configuration and unchanged subscription adapter. Each
  worker verifies the frozen protocol and source hashes before any call.
- Offline audit: 15 test groups passed, including independent exact-reference
  checks for 1,100 worlds, technical retry/resume, serving exclusions and
  incomplete-analysis guards; live model calls: zero. An additional dummy
  process test verified inherited controller locking and SIGTERM cleanup.
- This protocol is complete. No extension smoke or formal call is permitted
  until this file's separate registration commit has been pushed to main.
