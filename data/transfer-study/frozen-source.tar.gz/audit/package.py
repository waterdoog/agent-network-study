#!/usr/bin/env python3
"""Archive completed transfer runs without changing any retained raw record.

Preparation is safe; running this script requires all 6 smoke and 108 formal
final statuses and an inactive controller. It never calls a model or scores
quality. Source/protocol bytes come from their registered Git revisions.
"""
import argparse
import contextlib
import datetime
import fcntl
import gzip
import hashlib
import io
import json
import re
import shutil
import subprocess
import tarfile
import tempfile
from collections import Counter
from pathlib import Path

TASK = Path(__file__).resolve().parents[2]
DEFAULT_STUDY = TASK / 'work/agent-network-study/scripts/transfer-study'
REGISTRATION = 'f34dc4606b11e8d711430ad2da65c6e05e69a8ff'
SOURCE = 'cec9631550af39e7c0f8435bb6908c4eff41c1d2'
MODEL = 'gpt-6-astra'
EXPECTED = {'smoke': 6, 'formal': 108}
FORBIDDEN = {'registration-receipt.json', 'controller.lock', 'auth.json', '.env'}
CREDENTIAL_PATTERN = re.compile(
    rb'(?i)(?:"(?:access_token|refresh_token|id_token|api_key|account_id|authorization)"\s*:\s*"[^"\s]+'
    rb'|Bearer\s+[A-Za-z0-9._-]{20,}|\bsk-[A-Za-z0-9_-]{20,})')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def canonical_sha(obj):
    # These world/reference records use only ASCII keys/IDs and integer values;
    # compact insertion-ordered JSON matches JSON.stringify in the frozen code.
    return sha(json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode())


def git_bytes(repo, revision, name):
    if not re.fullmatch(r'[a-f0-9]{40}', revision):
        raise ValueError('A full 40-character revision is required')
    return subprocess.check_output(['git', '-C', str(repo), 'show', f'{revision}:{name}'])


def json_file(path):
    return json.loads(path.read_text())


def safe_raw(path, data):
    if CREDENTIAL_PATTERN.search(data):
        raise RuntimeError(f'Potential credential-shaped content requires explicit review; nothing redacted: {path}')


def record(path, name):
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f'Only regular files may be archived: {name}')
    data = path.read_bytes()
    safe_raw(name, data)
    return {'name': name, 'path': path, 'sha256': sha(data), 'bytes': len(data)}


def blob(data, name):
    safe_raw(name, data)
    return {'name': name, 'data': data, 'sha256': sha(data), 'bytes': len(data)}


def jsonl(path, issues):
    if not path.exists():
        return []
    rows = []
    for n, line in enumerate(path.read_bytes().splitlines(), 1):
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except (ValueError, UnicodeError):
            issues.append({'file': path.name, 'line': n, 'note': 'Invalid raw line retained verbatim; not counted as verified usage.'})
    return rows


def expected_entries(mode):
    seeds = [1, 2] if mode == 'smoke' else list(range(1001, 1049))
    return {(seed, arm) for i, seed in enumerate(seeds)
            for arm in (['strict', 'permissive', 'full_information']
                        if mode == 'smoke' or i % 4 == 0 else ['strict', 'permissive'])}


def completeness_gate(runs):
    plans = {}
    # No final contents, model messages or usage ledgers are read until BOTH
    # modes have all final status files and their fixed planned identities.
    for mode, count in EXPECTED.items():
        plan = json_file(runs / mode / 'plan.json')
        entries = plan['plan']
        if len(entries) != count or {(e['seed'], e['arm']) for e in entries} != expected_entries(mode):
            raise RuntimeError(f'{mode}: plan differs from registered sample')
        if len({e['id'] for e in entries}) != count:
            raise RuntimeError(f'{mode}: duplicate episode IDs')
        if any(e['id'] != f'W{e["seed"]}_{e["arm"]}' for e in entries):
            raise RuntimeError(f'{mode}: unexpected episode identity')
        missing = [e['id'] for e in entries if not (runs / mode / e['id'] / 'final.json').is_file()]
        if missing:
            raise RuntimeError(f'Collection incomplete: {mode} has {len(missing)} missing final statuses; no archive or quality inspection')
        plans[mode] = plan
    return plans


@contextlib.contextmanager
def inactive_controller(runs):
    path = runs / 'controller.lock'
    stream = path.open('rb') if path.exists() else None
    try:
        if stream:
            try:
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise RuntimeError('Controller or inherited runner lock is active; wait for collection to exit') from exc
        yield
    finally:
        if stream:
            stream.close()


def resource_audit(runs, mode, plan):
    directory = runs / mode
    counts = Counter()
    serving = Counter()
    event_serving = Counter()
    unique_responses = {}
    started, terminal = set(), set()
    logical_calls = set()
    issues = []
    known = Counter()
    verified = Counter()
    for entry in plan['plan']:
        ep = directory / entry['id']
        final = json_file(ep / 'final.json')
        if any(final.get(k) != entry[k] for k in ('id', 'seed', 'arm')):
            raise RuntimeError('Final episode identity mismatch')
        if final['status'] not in {'submitted', 'model-no-submission', 'technical-exhausted'}:
            raise RuntimeError(f'{mode}/{entry["id"]}: unresolved status')
        if final['attempt'] not in (1, 2):
            raise RuntimeError('Unexpected third attempt')
        if any(p.name not in {'attempt-1', 'attempt-2'} for p in ep.glob('attempt-*')):
            raise RuntimeError('Unexpected attempt directory')
        attempts = [ep / f'attempt-{i}' for i in range(1, final['attempt'] + 1)]
        if len(list(ep.glob('attempt-*'))) != len(attempts):
            raise RuntimeError('Attempt directories do not match selected attempt')
        if len(final['attempts']) != len(attempts):
            raise RuntimeError('Final attempt history does not match preserved attempts')
        counts['episodes'] += 1
        counts['technical_exhausted_episodes'] += final['status'] == 'technical-exhausted'
        counts['episode_reruns'] += final['attempt'] == 2
        world = json_file(ep / 'world.json')
        answer = json_file(ep / 'answer-key.json')
        hashes = plan['worlds'][str(entry['seed'])]
        if canonical_sha(world) != hashes['world_sha256'] or canonical_sha(answer) != hashes['answer_key_sha256']:
            raise RuntimeError('World/reference hash differs from saved pre-call plan')
        if final['world_sha256'] != hashes['world_sha256'] or final['answer_key_sha256'] != hashes['answer_key_sha256']:
            raise RuntimeError('Final world/reference hash differs from plan')
        for index, attempt in enumerate(attempts, 1):
            summary = json_file(attempt / 'summary.json')
            if summary['attempt'] != index:
                raise RuntimeError('Attempt number mismatch')
            if index < final['attempt'] and summary['status'] != 'technical-failure':
                raise RuntimeError('A nontechnical outcome was rerun')
            if summary.get('serving_exclusion'):
                raise RuntimeError('Serving exclusion remains; archive requires explicit investigation')
            counts['episode_attempts'] += 1
            counts['technical_episode_attempts'] += summary['status'] == 'technical-failure'
            local_issues = []
            events = jsonl(attempt / 'events.jsonl', local_issues)
            llm = [e for e in events if e.get('evt') == 'llm']
            counts['saved_model_requests'] += sum(e.get('evt') == 'model.request' for e in events)
            counts['saved_model_replies'] += sum(e.get('evt') == 'model.reply' for e in events)
            for event in llm:
                event_serving[str(event.get('served'))] += 1
                for field, target in [('ti', 'input_tokens'), ('to', 'output_tokens')]:
                    value = event[field]
                    if not isinstance(value, (int, float)) or value < 0:
                        raise RuntimeError('Nonverifiable event token count')
                    verified[target] += value
                verified['calls'] += 1
                if event.get('reasoning_tokens') is not None:
                    verified['reasoning_tokens'] += event['reasoning_tokens']
                    verified['reasoning_known_calls'] += 1
            if not local_issues:
                if len(llm) != summary['usage']['successful_calls'] or sum(e['ti'] for e in llm) != summary['usage']['input_tokens'] or sum(e['to'] for e in llm) != summary['usage']['output_tokens']:
                    raise RuntimeError('Attempt usage does not reconcile with saved llm events')
            ledger = jsonl(attempt / 'transport-ledger.jsonl', local_issues)
            for row in ledger:
                identity = (entry['id'], index, row.get('attempt_id'))
                if row.get('kind') == 'attempt_started':
                    counts['transport_attempt_starts'] += 1
                    started.add(identity)
                    logical_calls.add((entry['id'], index, row.get('tag'), row.get('request_sha256')))
                if row.get('kind') == 'attempt_error':
                    counts['transport_attempt_errors'] += 1
                if row.get('kind') != 'response':
                    continue
                counts['upstream_response_records'] += 1
                terminal.add(identity)
                response_id = row.get('response_id')
                key = ('response', response_id) if response_id else ('attempt', *identity)
                response = {k: row.get(k) for k in ('served', 'usage', 'response_status', 'output_sha256')}
                if key in unique_responses:
                    if unique_responses[key] != response:
                        raise RuntimeError('Repeated response ID has inconsistent usage/content metadata')
                    counts['duplicate_response_records'] += 1
                    continue
                unique_responses[key] = response
                serving[str(row.get('served'))] += 1
                usage = row.get('usage')
                if not usage or any(not isinstance(usage.get(k), (int, float)) for k in ('input_tokens', 'output_tokens')):
                    counts['responses_without_verified_usage'] += 1
                    continue
                known['responses_with_usage'] += 1
                known['input_tokens'] += usage['input_tokens']
                known['output_tokens'] += usage['output_tokens']
                reason = (usage.get('output_tokens_details') or {}).get('reasoning_tokens')
                if reason is not None:
                    known['reasoning_tokens'] += reason
                    known['reasoning_known_responses'] += 1
            for item in local_issues:
                item['episode'] = entry['id']
                item['episode_attempt'] = index
            issues.extend(local_issues)
    for key in ('responses_with_usage', 'input_tokens', 'output_tokens', 'reasoning_tokens', 'reasoning_known_responses'):
        known.setdefault(key, 0)
    for key in ('calls', 'input_tokens', 'output_tokens', 'reasoning_tokens', 'reasoning_known_calls'):
        verified.setdefault(key, 0)
    known['total_tokens'] = known['input_tokens'] + known['output_tokens']
    verified['total_tokens'] = verified['input_tokens'] + verified['output_tokens']
    return {
        'mode': mode, 'counts': dict(sorted(counts.items())),
        'logical_caller_requests': len(logical_calls),
        'unique_upstream_responses': len(unique_responses),
        'started_attempts_without_terminal_response_record': len(started - terminal),
        'upstream_served_models': dict(sorted(serving.items())),
        'verified_event_served_models': dict(sorted(event_serving.items())),
        'known_ledger_usage_all_attempts': dict(sorted(known.items())),
        'verified_llm_event_usage_all_attempts': dict(sorted(verified.items())),
        'raw_jsonl_parse_issues': issues, 'cost_usd': None,
        'accounting_note': 'Ledger totals sum unique upstream responses with reported usage across all episode/call attempts, including technical attempts. Missing terminal responses can have unknown consumption. Reasoning is part of output, not added again. No monetary cost is inferred.',
    }


def make_archive(path, records):
    with path.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for row in sorted(records, key=lambda r: r['name']):
                info = tarfile.TarInfo(row['name'])
                info.size = row['bytes']
                info.mode = 0o644
                info.mtime = info.uid = info.gid = 0
                info.uname = info.gname = ''
                if 'data' in row:
                    archive.addfile(info, io.BytesIO(row['data']))
                else:
                    if file_sha(row['path']) != row['sha256']:
                        raise RuntimeError('Raw input changed while packaging')
                    with row['path'].open('rb') as source:
                        archive.addfile(info, source)


def verify_restore(stage, archives):
    with tempfile.TemporaryDirectory(prefix='transfer-restore-') as temp:
        # macOS /var can resolve to /private/var; compare canonical roots.
        root = Path(temp).resolve()
        seen = set()
        for name, rows in archives.items():
            expected = {r['name']: r for r in rows}
            with tarfile.open(stage / name, 'r:gz') as archive:
                members = archive.getmembers()
                if {m.name for m in members} != set(expected) or len(members) != len(expected):
                    raise RuntimeError('Archive membership mismatch')
                for member in members:
                    if not member.isfile() or member.name in seen:
                        raise RuntimeError('Unsafe or duplicate archive member')
                    dest = root / member.name
                    if not dest.resolve().is_relative_to(root):
                        raise RuntimeError('Unsafe archive path')
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    with archive.extractfile(member) as source, dest.open('wb') as target:
                        shutil.copyfileobj(source, target)
                    row = expected[member.name]
                    if file_sha(dest) != row['sha256'] or dest.stat().st_size != row['bytes']:
                        raise RuntimeError('Restored bytes differ from source')
                    seen.add(member.name)
        if len(seen) != sum(len(x) for x in archives.values()):
            raise RuntimeError('Restore count mismatch')
    return len(seen)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--study', type=Path, default=DEFAULT_STUDY)
    ap.add_argument('--protocol', type=Path, default=TASK / 'work/paper-transfer-registration/docs/PREREGISTRATION-independent-task.md')
    ap.add_argument('--registration-ref', default=REGISTRATION)
    ap.add_argument('--source-ref', default=SOURCE)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--reviewed-operational-list', type=Path,
                    help='Optional JSON list of runs-relative operational files explicitly reviewed for safe inclusion. Receipt and lock are always excluded.')
    args = ap.parse_args()
    study = args.study.resolve(); runs = study / 'runs'; repo = study.parents[1]
    out = args.out.resolve()
    if out.exists():
        raise RuntimeError('Output already exists; choose a new path rather than overwrite an archive')
    reviewed = json_file(args.reviewed_operational_list) if args.reviewed_operational_list else []
    if not isinstance(reviewed, list) or any(not isinstance(x, str) for x in reviewed):
        raise RuntimeError('Reviewed operations list must be a JSON string array')
    with inactive_controller(runs):
        plans = completeness_gate(runs)
        source_manifest = json.loads(git_bytes(repo, args.source_ref, 'scripts/transfer-study/source-manifest.json'))
        protocol = args.protocol.resolve()
        protocol_repo = protocol.parent.parent
        protocol_name = protocol.relative_to(protocol_repo).as_posix()
        protocol_bytes = git_bytes(protocol_repo, args.registration_ref, protocol_name)
        if protocol.read_bytes() != protocol_bytes:
            raise RuntimeError('Working protocol differs from registered Git bytes')
        for mode, plan in plans.items():
            if plan['registration_commit'] != args.registration_ref or plan['protocol_sha256'] != sha(protocol_bytes):
                raise RuntimeError(f'{mode}: protocol provenance mismatch')
            if plan['source_manifest'] != source_manifest:
                raise RuntimeError(f'{mode}: frozen source manifest mismatch')
        resources = {mode: resource_audit(runs, mode, plan) for mode, plan in plans.items()}
        archives = {}
        excluded = []
        for mode in EXPECTED:
            paths = list((runs / mode).rglob('*'))
            allowed_root = {'plan.json'} | {e['id'] for e in plans[mode]['plan']}
            for path in paths:
                if path.is_symlink():
                    raise RuntimeError('Symlink in raw run directory')
            rows = []
            for path in sorted(p for p in paths if p.is_file()):
                relative = path.relative_to(runs).as_posix()
                if path.name in FORBIDDEN or path.name.endswith('.lock') or path.name.startswith('.env'):
                    excluded.append({'file': relative, 'reason': 'Credential/lock exclusion'})
                    continue
                first = path.relative_to(runs / mode).parts[0]
                if first not in allowed_root:
                    if path.parent != runs / mode:
                        raise RuntimeError('Unexpected run subdirectory; do not silently omit unplanned raw records')
                    if relative not in reviewed:
                        excluded.append({'file': relative, 'reason': 'Operational file requires explicit safe-review list'})
                    continue
                rows.append(record(path, 'runs/' + relative))
            archives[f'{mode}.tar.gz'] = rows
        source_rows = []
        source_paths = set()
        for name, checksum in source_manifest['files'].items():
            relative = (study / name).resolve().relative_to(repo).as_posix()
            data = git_bytes(repo, args.source_ref, relative)
            if sha(data) != checksum:
                raise RuntimeError('Registered source bytes disagree with frozen hash')
            source_rows.append(blob(data, 'agent-network-study/' + relative)); source_paths.add(relative)
        for relative in ('scripts/transfer-study/README.md', 'scripts/transfer-study/tests.mjs',
                         'scripts/transfer-study/source-manifest.json'):
            if relative not in source_paths:
                source_rows.append(blob(git_bytes(repo, args.source_ref, relative), 'agent-network-study/' + relative))
        source_rows.append(blob(protocol_bytes, 'paper-registration/' + protocol_name))
        source_rows.append(record(Path(__file__).resolve(), 'audit/package.py'))
        archives['frozen-source.tar.gz'] = source_rows
        operation_rows = []
        for name in reviewed:
            path = (runs / name).resolve()
            if not path.is_relative_to(runs) or path.name in FORBIDDEN or path.name.endswith('.lock') or path.name.startswith('.env'):
                raise RuntimeError('Forbidden operational inclusion')
            target = 'runs/' + path.relative_to(runs).as_posix()
            if any(row['name'] == target for rows in archives.values() for row in rows):
                raise RuntimeError('Operational list duplicates an already included raw file')
            operation_rows.append(record(path, target))
        if operation_rows:
            archives['operations-reviewed.tar.gz'] = operation_rows
        root_files = [p for p in runs.iterdir() if p.is_file()]
        for path in root_files:
            name = path.relative_to(runs).as_posix()
            if name not in reviewed:
                excluded.append({'file': name, 'reason': 'Receipt/lock excluded; other run-root operational files were not explicitly safe-reviewed'})
        all_rows = [r for rows in archives.values() for r in rows]
        if len({r['name'] for r in all_rows}) != len(all_rows):
            raise RuntimeError('Duplicate archive paths')
        out.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='transfer-package-', dir=out.parent) as temp:
            stage = Path(temp)
            for name, rows in archives.items():
                make_archive(stage / name, rows)
            restored = verify_restore(stage, archives)
            file_lines = ''.join(f'{r["sha256"]}  {r["name"]}\n' for r in sorted(all_rows, key=lambda r: r['name']))
            (stage / 'FILES.sha256').write_text(file_lines)
            manifest = {
                'schema': 1, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'registration_commit': args.registration_ref, 'source_commit': args.source_ref,
                'protocol_sha256': sha(protocol_bytes), 'model': MODEL, 'cost_usd': None,
                'archive_files': {name: {'files': len(rows), 'uncompressed_bytes': sum(r['bytes'] for r in rows), 'sha256': file_sha(stage / name)} for name, rows in archives.items()},
                'restored_files_verified': restored, 'raw_bytes_modified': False,
                'quality_analysis_performed': False, 'resource_audit': resources,
                'reviewed_operational_inclusions': reviewed, 'excluded_files': excluded,
                'packaging_helper_sha256': file_sha(Path(__file__).resolve()),
            }
            (stage / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
            (stage / 'README.md').write_text(f'''# Transfer-study raw archive (author-facing)

Paper registration commit: `{args.registration_ref}`.
Experiment source commit: `{args.source_ref}`.
Protocol SHA-256: `{sha(protocol_bytes)}`.
Model: `gpt-6-astra`; transport: ChatGPT subscription; USD cost: unknown/null.

This package was made only after all 6 smoke and 108 formal final statuses
existed and the controller/runner lock was inactive. It preserves every
included raw file byte-for-byte, including technical attempts, transport
ledgers, complete parsed prompts/messages, tool inputs/outputs and final
records. It does not reconstruct SSE wire bytes that were never saved.
No quality outcome was computed by the packaging helper. Known resource
counts per mode are in `manifest.json`; missing terminal responses can leave
unobserved consumption, so these are known-usage sums, not guaranteed billing.
Reasoning tokens are included in output tokens and are not added twice.

`formal.tar.gz` and `smoke.tar.gz` restore under `runs/`.
`frozen-source.tar.gz` contains the registered source tree under
`agent-network-study/`, the frozen protocol under `paper-registration/`,
and the post-registration packaging helper under `audit/`.
Any `operations-reviewed.tar.gz` contains only explicitly reviewed operational
files named in the manifest. Credentials, registration receipt and controller
lock are excluded. All other excluded operational files and reasons are listed;
no included content was silently redacted or changed. This raw author-facing
archive is not automatically an anonymous public supplement.

## Verify and restore offline

```sh
shasum -a 256 -c SHA256SUMS
mkdir restored
for archive in *.tar.gz; do tar -xzf "$archive" -C restored; done
(cd restored && shasum -a 256 -c ../FILES.sha256)
```

Every tar member was extracted into a clean temporary directory and matched
its original SHA-256 and byte count before publication ({restored} files).
Source/protocol bytes were also checked against their full Git revisions.
No model/login is needed for deterministic testing or scoring:

```sh
node restored/agent-network-study/scripts/transfer-study/tests.mjs
node restored/agent-network-study/scripts/transfer-study/score.mjs --run restored/runs/smoke --validate-only
node restored/agent-network-study/scripts/transfer-study/score.mjs --run restored/runs/formal --out reproduced-results.json
```

The formal scorer refuses a confirmatory primary result with unresolved
technical comparison pairs. Smoke never joins formal analysis. Do not run
collection/control commands when reproducing this offline archive.
''')
            names = sorted(p for p in stage.iterdir() if p.is_file())
            (stage / 'SHA256SUMS').write_text(''.join(f'{file_sha(p)}  {p.name}\n' for p in names))
            for line in (stage / 'SHA256SUMS').read_text().splitlines():
                checksum, name = line.split('  ', 1)
                if file_sha(stage / name) != checksum:
                    raise RuntimeError('Package checksum verification failed')
            # A final snapshot check catches concurrent changes to retained inputs.
            if any(file_sha(r['path']) != r['sha256'] for r in all_rows if 'path' in r):
                raise RuntimeError('An original raw file changed during archival')
            shutil.copytree(stage, out)
        print(json.dumps({'archive': str(out), 'restored_files_verified': restored,
                          'resources': resources, 'quality_analysis_performed': False}, indent=2))


if __name__ == '__main__':
    main()
