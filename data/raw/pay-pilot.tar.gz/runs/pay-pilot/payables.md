# payables — pay-pilot
episodes=40 (summary.json present, on protocol); excluded (off-protocol settings)=0; CRASHED directories=0; planned (manifest)=40

## Delivery (read this before any contrast below)

> This analysis excludes lost beats from the delivered-only means (it does not count them as 0)
> and reports the planned denominator separately: a model failure counts as Q = 0 there, a
> technical loss stays missing and is bracketed in the primary-contrast bounds.

- beats: 40, no artifact: 0 (0%)
- worst cell: arm=A L=1 M=0 at 0%; spread across cells 0%

| cell | beats | no artifact | rate |
|---|---|---|---|
| arm=A L=1 M=0 | 5 | 0 | 0% |
| arm=A L=4 M=0 | 5 | 0 | 0% |
| arm=B L=1 M=0 | 5 | 0 | 0% |
| arm=B L=4 M=0 | 5 | 0 | 0% |
| arm=C L=1 M=0 | 5 | 0 | 0% |
| arm=C L=4 M=0 | 5 | 0 | 0% |
| arm=D L=1 M=0 | 5 | 0 | 0% |
| arm=D L=4 M=0 | 5 | 0 | 0% |


### Planned, summarised, delivered, and failure kinds per cell (T1)

Planned comes from manifest.json; summarised is a summary.json on
protocol; delivered is a parsed artifact. model = the requester ended without a submission or the
artifact did not parse; technical = an LLM call failed, the beat crashed, or the scorer threw.

| L | M | arm | planned | summarised | delivered | model | technical | crashed |
|---|---|---|---|---|---|---|---|---|
| 1 | 0 | A | 5 | 5 | 5 | 0 | 1 | 0 |
| 1 | 0 | B | 5 | 5 | 5 | 0 | 0 | 0 |
| 1 | 0 | C | 5 | 5 | 5 | 0 | 0 | 0 |
| 1 | 0 | D | 5 | 5 | 5 | 0 | 0 | 0 |
| 4 | 0 | A | 5 | 5 | 5 | 0 | 0 | 0 |
| 4 | 0 | B | 5 | 5 | 5 | 0 | 0 | 0 |
| 4 | 0 | C | 5 | 5 | 5 | 0 | 0 | 0 |
| 4 | 0 | D | 5 | 5 | 5 | 0 | 0 | 0 |

## Per-cell means (T1)

Q = share of the 6 orders with balance, status and payable all correct; field = share of the 24
invoice/discount/accepted/paid attributes correct. Q and field are over delivered beats; Q(pl) and
field(pl) are over the planned denominator (model failures as 0, technical losses missing). complete
= share of delivered beats with Q = 1. asked = distinct cards asked (ask_agent, builder consults);
read = distinct cards listed or read; contacted = their union. store use = share of episodes with
at least one read_store call. Tokens are whole-system, in thousands, missing when lost in a crash.

| L | M | arm | n | delivered | Q | Q(pl) | field | field(pl) | F1 | complete | tokens (k) | asks | lists | reads | searches | asked | read | contacted | store use |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0 | A | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 67.4 | 9.8 | 0.0 | 0.0 | 3.2 | 7.8 | 0.0 | 7.8 | 0% |
| 1 | 0 | B | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 103.2 | 0.0 | 6.0 | 24.0 | 2.6 | 0.0 | 6.0 | 6.0 | 100% |
| 1 | 0 | C | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 46.2 | 6.0 | 0.0 | 0.0 | 2.8 | 6.0 | 0.0 | 6.0 | 0% |
| 1 | 0 | D | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 89.7 | 0.0 | 6.0 | 24.0 | 2.6 | 0.0 | 6.0 | 6.0 | 100% |
| 4 | 0 | A | 5 | 100% |  0.967 |  0.967 |  0.992 |  0.992 |  0.986 | 80% | 222.3 | 28.2 | 0.0 | 0.0 | 2.6 | 10.4 | 0.0 | 10.4 | 0% |
| 4 | 0 | B | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 121.3 | 0.0 | 6.0 | 28.8 | 2.6 | 0.0 | 6.0 | 6.0 | 100% |
| 4 | 0 | C | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 142.7 | 15.8 | 0.0 | 0.0 | 2.6 | 6.2 | 0.0 | 6.2 | 0% |
| 4 | 0 | D | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 115.9 | 0.0 | 6.2 | 24.0 | 2.8 | 0.0 | 6.2 | 6.2 | 100% |

### Diagnostics from T1.html and events (per cell)

html = share of episodes whose T1.html exists. trunc = share of tool.ask events whose answer hit the
token cap (fin = length), pooled over the cell. unresolved = mean count of <li> items in
<section id="unresolved">. evidence full = mean share of orders whose cited evidence includes all
four current document ids; evidence non-current = mean share of orders citing at least one
background or superseded id. adoption (M1 only) = adopted / 4 conflicts. All over delivered beats
whose T1.html exists.

| L | M | arm | n | html | trunc | unresolved | evidence full | evidence non-current | adoption |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 0 | A | 5 | 100% | 12% | 0.0 |  1.000 |  0.000 | n/a |
| 1 | 0 | B | 5 | 100% | -- | 0.0 |  1.000 |  0.000 | n/a |
| 1 | 0 | C | 5 | 100% | 0% | 0.0 |  1.000 |  0.000 | n/a |
| 1 | 0 | D | 5 | 100% | -- | 0.0 |  1.000 |  0.000 | n/a |
| 4 | 0 | A | 5 | 100% | 13% | 0.0 |  0.967 |  0.000 | n/a |
| 4 | 0 | B | 5 | 100% | -- | 0.0 |  1.000 |  0.000 | n/a |
| 4 | 0 | C | 5 | 100% | 27% | 0.0 |  1.000 |  0.000 | n/a |
| 4 | 0 | D | 5 | 100% | -- | 0.0 |  1.000 |  0.000 | n/a |

## Contrasts per (L, M) — Q, paired by seed

S = ½[(B−A)+(D−C)] is the store effect, F = ½[(A−C)+(B−D)] the formation effect. If B−A and D−C
disagree, S averages over a real interaction; read the interaction line, not just S. Each cell is
given under both denominators: delivered-only (a seed needs all four arms delivered) and planned
(model failures enter as Q = 0; a seed with a technical loss in any arm is dropped).

### L=1 M=0
#### delivered-only
```
                sandbox     store
  open         1.000      1.000     A,B
  bounded      1.000      1.000     C,D
```
  S                    =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  F                    =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  B-A                  =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  D-C                  =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  (B-A)-(D-C)          =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5

#### planned
```
                sandbox     store
  open         1.000      1.000     A,B
  bounded      1.000      1.000     C,D
```
  S                    =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  F                    =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  B-A                  =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  D-C                  =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  (B-A)-(D-C)          =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5

### L=2 M=0
#### delivered-only
  incomplete (no seed has all four arms)

#### planned
  incomplete (no seed has all four arms)

### L=4 M=0
#### delivered-only
```
                sandbox     store
  open         0.967      1.000     A,B
  bounded      1.000      1.000     C,D
```
  S                    =  0.017   95% CI [ 0.000,  0.050]   spans 0   n=5
  F                    = -0.017   95% CI [-0.050,  0.000]   spans 0   n=5
  B-A                  =  0.033   95% CI [ 0.000,  0.100]   spans 0   n=5
  D-C                  =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  (B-A)-(D-C)          =  0.033   95% CI [ 0.000,  0.100]   spans 0   n=5

#### planned
```
                sandbox     store
  open         0.967      1.000     A,B
  bounded      1.000      1.000     C,D
```
  S                    =  0.017   95% CI [ 0.000,  0.050]   spans 0   n=5
  F                    = -0.017   95% CI [-0.050,  0.000]   spans 0   n=5
  B-A                  =  0.033   95% CI [ 0.000,  0.100]   spans 0   n=5
  D-C                  =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  (B-A)-(D-C)          =  0.033   95% CI [ 0.000,  0.100]   spans 0   n=5

### L=1 M=1
#### delivered-only
  incomplete (no seed has all four arms)

#### planned
  incomplete (no seed has all four arms)

### L=2 M=1
#### delivered-only
  incomplete (no seed has all four arms)

#### planned
  incomplete (no seed has all four arms)

### L=4 M=1
#### delivered-only
  incomplete (no seed has all four arms)

#### planned
  incomplete (no seed has all four arms)

### S on secondary metrics

| L | M | metric | denominator | S | 95% CI | n |
|---|---|---|---|---|---|---|
| 1 | 0 | field accuracy | delivered-only |  0.000 | [ 0.000,  0.000] | 5 |
| 4 | 0 | field accuracy | delivered-only |  0.004 | [ 0.000,  0.012] | 5 |
| 1 | 0 | field accuracy | planned |  0.000 | [ 0.000,  0.000] | 5 |
| 4 | 0 | field accuracy | planned |  0.004 | [ 0.000,  0.012] | 5 |
| 1 | 0 | requirement F1 | delivered-only |  0.000 | [ 0.000,  0.000] | 5 |
| 4 | 0 | requirement F1 | delivered-only |  0.007 | [ 0.000,  0.021] | 5 |

## Primary contrast

K = S(L=4) − S(L=1), computed per seed (a seed must have all four arms at both L) then averaged.
K > 0 alone can mean store went from worse to less bad; a quality gain at high burden needs
S(L=4) > 0 as well. Both are reported, neither is selected. Seed sets: K and "S(L=4) | K seeds" use
the seeds complete at both L=1 and L=4, so the two primaries share n; "S(L=4) all" uses every seed
complete at L=4 and "S(L=1) all" every seed complete at L=1.

### M=0 (pre-registered)
#### delivered-only
  K                    =  0.017   95% CI [ 0.000,  0.050]   spans 0   n=5   [seeds complete at L=1 and L=4]
  S(L=4) | K seeds     =  0.017   95% CI [ 0.000,  0.050]   spans 0   n=5   [same seeds as K]
  S(L=4) all           =  0.017   95% CI [ 0.000,  0.050]   spans 0   n=5   [seeds complete at L=4]
  S(L=1) all           =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5   [seeds complete at L=1]

#### planned
  K                    =  0.017   95% CI [ 0.000,  0.050]   spans 0   n=5   [seeds complete at L=1 and L=4]
  S(L=4) | K seeds     =  0.017   95% CI [ 0.000,  0.050]   spans 0   n=5   [same seeds as K]
  S(L=4) all           =  0.017   95% CI [ 0.000,  0.050]   spans 0   n=5   [seeds complete at L=4]
  S(L=1) all           =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5   [seeds complete at L=1]

#### bounds (planned denominator, missing Q filled)
  K | missing=0        =  0.017   95% CI [ 0.000,  0.050]   spans 0   n=5   [5 planned seeds, 0 of 40 beats filled]
  S(L=4) | missing=0   =  0.017   95% CI [ 0.000,  0.050]   spans 0   n=5   [5 planned seeds, 0 of 20 beats filled]
  K | missing=1        =  0.017   95% CI [ 0.000,  0.050]   spans 0   n=5   [5 planned seeds, 0 of 40 beats filled]
  S(L=4) | missing=1   =  0.017   95% CI [ 0.000,  0.050]   spans 0   n=5   [5 planned seeds, 0 of 20 beats filled]

### M=1 (secondary: conflicts)
#### delivered-only
  K                    incomplete (no complete seed blocks)   [seeds complete at L=1 and L=4]
  S(L=4) | K seeds     incomplete (no complete seed blocks)   [same seeds as K]
  S(L=4) all           incomplete (no complete seed blocks)   [seeds complete at L=4]
  S(L=1) all           incomplete (no complete seed blocks)   [seeds complete at L=1]

#### planned
  K                    incomplete (no complete seed blocks)   [seeds complete at L=1 and L=4]
  S(L=4) | K seeds     incomplete (no complete seed blocks)   [same seeds as K]
  S(L=4) all           incomplete (no complete seed blocks)   [seeds complete at L=4]
  S(L=1) all           incomplete (no complete seed blocks)   [seeds complete at L=1]

#### bounds (planned denominator, missing Q filled)
  K | missing=0        incomplete (no complete seed blocks)   [0 planned seeds, 0 of 0 beats filled]
  S(L=4) | missing=0   incomplete (no complete seed blocks)   [0 planned seeds, 0 of 0 beats filled]
  K | missing=1        incomplete (no complete seed blocks)   [0 planned seeds, 0 of 0 beats filled]
  S(L=4) | missing=1   incomplete (no complete seed blocks)   [0 planned seeds, 0 of 0 beats filled]

### Conflicts: S(M1) − S(M0) per L

Per seed, the same world with the four historical records replaced by conflicting ones.

#### delivered-only
  L=1                  incomplete (no complete seed blocks)
  L=2                  incomplete (no complete seed blocks)
  L=4                  incomplete (no complete seed blocks)
  K(M1)-K(M0)          incomplete (no complete seed blocks)

#### planned
  L=1                  incomplete (no complete seed blocks)
  L=2                  incomplete (no complete seed blocks)
  L=4                  incomplete (no complete seed blocks)
  K(M1)-K(M0)          incomplete (no complete seed blocks)

## Wrong adoption (M1)

Share of the 4 conflicting values (one per evidence group, on four distinct orders) that the
artifact carries in the conflicted field, over delivered beats whose T1.html exists. A lower
B−A or D−C means reading the folder adopted fewer superseded values than asking its keeper.

| L | A | B | C | D | B−A | 95% CI | D−C | 95% CI | n |
|---|---|---|---|---|---|---|---|---|---|
| 1 | incomplete | | | | | | | | 0 |
| 2 | incomplete | | | | | | | | 0 |
| 4 | incomplete | | | | | | | | 0 |

## Tokens (T1, k) and the token cost of store

Whole-system tokens for the beat, all roles summed. The build receipt is the same in every arm, so
most of a difference here should be listing and reading documents versus asking for them; the
per-role table below says where it actually sits. A beat whose stats were lost in a crash is
missing, not 0.

| L | M | A | B | C | D | B−A | 95% CI | D−C | 95% CI | n |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0 | 67.4 | 103.2 | 46.2 | 89.7 | 35.9 | [13.0, 57.6] | 43.5 | [27.2, 56.1] | 5 |
| 2 | 0 | incomplete | | | | | | | | 0 |
| 4 | 0 | 222.3 | 121.3 | 142.7 | 115.9 | -101.0 | [-182.3, -16.1] | -26.8 | [-66.5, 13.8] | 5 |
| 1 | 1 | incomplete | | | | | | | | 0 |
| 2 | 1 | incomplete | | | | | | | | 0 |
| 4 | 1 | incomplete | | | | | | | | 0 |

### Tokens by role (T1, k)

Summed from the llm events of the beat by tag: req.* = requester, ask.* = responder, build.* =
builder, consult.* = builder consults (shown when non-zero). Same per-seed contrasts as above.

| L | M | role | A | B | C | D | B−A | 95% CI | D−C | 95% CI | n |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0 | requester | 44.3 | 99.0 | 28.3 | 86.0 | 54.6 | [38.8, 71.5] | 57.7 | [43.5, 69.3] | 5 |
| 1 | 0 | responder | 19.3 | 0.0 | 13.9 | 0.0 | -19.3 | [-30.4, -13.1] | -13.9 | [-15.1, -12.8] | 5 |
| 1 | 0 | builder | 3.8 | 4.3 | 4.0 | 3.8 | 0.5 | [-0.3, 1.1] | -0.2 | [-1.6, 0.9] | 5 |
| 2 | 0 | requester | incomplete | | | | | | | | 0 |
| 2 | 0 | responder | incomplete | | | | | | | | 0 |
| 2 | 0 | builder | incomplete | | | | | | | | 0 |
| 4 | 0 | requester | 160.2 | 117.8 | 95.2 | 112.4 | -42.3 | [-112.1, 32.3] | 17.1 | [-11.9, 40.7] | 5 |
| 4 | 0 | responder | 57.5 | 0.0 | 43.7 | 0.0 | -57.5 | [-71.0, -43.8] | -43.7 | [-59.6, -26.3] | 5 |
| 4 | 0 | builder | 4.7 | 3.4 | 3.8 | 3.5 | -1.3 | [-2.5, -0.1] | -0.3 | [-0.9, 0.3] | 5 |
| 1 | 1 | requester | incomplete | | | | | | | | 0 |
| 1 | 1 | responder | incomplete | | | | | | | | 0 |
| 1 | 1 | builder | incomplete | | | | | | | | 0 |
| 2 | 1 | requester | incomplete | | | | | | | | 0 |
| 2 | 1 | responder | incomplete | | | | | | | | 0 |
| 2 | 1 | builder | incomplete | | | | | | | | 0 |
| 4 | 1 | requester | incomplete | | | | | | | | 0 |
| 4 | 1 | responder | incomplete | | | | | | | | 0 |
| 4 | 1 | builder | incomplete | | | | | | | | 0 |

## Notes

- n per cell (summarised, on protocol): L1M0A=5, L1M0B=5, L1M0C=5, L1M0D=5, L4M0A=5, L4M0B=5, L4M0C=5, L4M0D=5.
- Rows are restricted to the protocol settings (E=0, k=1, seedProfile=control, edgeCost=0, relayDepth=0, dirSize=100, reputation=off, searchCap=40);
  0 row(s) were excluded for other settings, and 0 CRASHED directories never wrote a summary.
- Q is the share of the 6 orders whose balance, status and payable are all correct (assertion ids
  o{i}_balance, o{i}_status, o{i}_payable); field accuracy is the share of the 24 invoice/discount/
  accepted/paid attributes correct. Both come from the T1 beat.
- Two denominators. Delivered-only: beats that produced no artifact are excluded from the Q, field
  and F1 means and from every paired contrast (a seed needs all four arms delivered to enter a
  block). Planned: a beat whose failureKind is model (no submission, or an artifact that did not
  parse) counts as Q = 0 and field accuracy 0; a technical loss (LLM call failed, beat crashed,
  scorer threw) stays missing, and the primary contrast is bracketed with missing Q set to 0 and
  to 1 over the planned seeds. Neither denominator counts a lost beat as 0 silently; the delivery
  table above is the place to look before reading any contrast. (The delivery module's "counts a
  lost beat as F1 = 0" note describes the older analyzers, not this one.)
- Token means and token contrasts keep beats that produced no artifact when their stats survived:
  the cost was spent. A beat with tokensUnknown, or a beat.crash event, has unknown cost and is
  missing from every token mean and contrast, never 0.
- asked = distinct cards in tool.ask events plus consult.ok targets; read = distinct cards in
  tool.list and tool.read events; contacted = the union of the two. All from events.jsonl for the
  T1 beat. The beat record's own `contacted` counter is not used.
- Wrong adoption compares each conflicted order's data-invoice/discount/accepted/paid in T1.html
  with the conflicting value the superseded record carries (numbers numerically, accepted as yes/no);
  evidence coverage reads data-evidence on the same rows against the instance's document ids.
- All intervals are descriptive 95% percentile bootstraps over seeds (base cases), keeping the four
  arms of a seed together, printed only when n ≥ 5. They are not corrected for multiple
  comparisons; the pre-registered test is a paired t-test on the per-seed K_i and S_i(L=4) with
  Holm correction, which this script does not perform.
- Q and field accuracy read `failedAll` from the beat record.
- failureKind was read from the beat record.