# payables — pay-pilot-m1
episodes=40 (summary.json present, on protocol); excluded (off-protocol settings)=0; CRASHED directories=0; planned (manifest)=40

## Delivery (read this before any contrast below)

> This analysis excludes lost beats from the delivered-only means (it does not count them as 0)
> and reports the planned denominator separately: a model failure counts as Q = 0 there, a
> technical loss stays missing and is bracketed in the primary-contrast bounds.

- beats: 40, no artifact: 0 (0%)
- worst cell: arm=A L=1 M=1 at 0%; spread across cells 0%

| cell | beats | no artifact | rate |
|---|---|---|---|
| arm=A L=1 M=1 | 5 | 0 | 0% |
| arm=A L=4 M=1 | 5 | 0 | 0% |
| arm=B L=1 M=1 | 5 | 0 | 0% |
| arm=B L=4 M=1 | 5 | 0 | 0% |
| arm=C L=1 M=1 | 5 | 0 | 0% |
| arm=C L=4 M=1 | 5 | 0 | 0% |
| arm=D L=1 M=1 | 5 | 0 | 0% |
| arm=D L=4 M=1 | 5 | 0 | 0% |


### Planned, summarised, delivered, and failure kinds per cell (T1)

Planned comes from manifest.json; summarised is a summary.json on
protocol; delivered is a parsed artifact. model = the requester ended without a submission or the
artifact did not parse; technical = an LLM call failed, the beat crashed, or the scorer threw.

| L | M | arm | planned | summarised | delivered | model | technical | crashed |
|---|---|---|---|---|---|---|---|---|
| 1 | 1 | A | 5 | 5 | 5 | 0 | 0 | 0 |
| 1 | 1 | B | 5 | 5 | 5 | 0 | 0 | 0 |
| 1 | 1 | C | 5 | 5 | 5 | 0 | 0 | 0 |
| 1 | 1 | D | 5 | 5 | 5 | 0 | 0 | 0 |
| 4 | 1 | A | 5 | 5 | 5 | 0 | 0 | 0 |
| 4 | 1 | B | 5 | 5 | 5 | 0 | 0 | 0 |
| 4 | 1 | C | 5 | 5 | 5 | 0 | 0 | 0 |
| 4 | 1 | D | 5 | 5 | 5 | 0 | 0 | 0 |

## Per-cell means (T1)

Q = share of the 6 orders with balance, status and payable all correct; field = share of the 24
invoice/discount/accepted/paid attributes correct. Q and field are over delivered beats; Q(pl) and
field(pl) are over the planned denominator (model failures as 0, technical losses missing). complete
= share of delivered beats with Q = 1. asked = distinct cards asked (ask_agent, builder consults);
read = distinct cards listed or read; contacted = their union. store use = share of episodes with
at least one read_store call. Tokens are whole-system, in thousands, missing when lost in a crash.

| L | M | arm | n | delivered | Q | Q(pl) | field | field(pl) | F1 | complete | tokens (k) | asks | lists | reads | searches | asked | read | contacted | store use |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | A | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 58.2 | 10.0 | 0.0 | 0.0 | 2.6 | 10.0 | 0.0 | 10.0 | 0% |
| 1 | 1 | B | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 112.3 | 0.0 | 6.0 | 24.0 | 2.4 | 0.0 | 6.0 | 6.0 | 100% |
| 1 | 1 | C | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 51.9 | 6.8 | 0.0 | 0.0 | 2.4 | 6.8 | 0.0 | 6.8 | 0% |
| 1 | 1 | D | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 99.9 | 0.0 | 6.0 | 24.0 | 2.8 | 0.0 | 6.0 | 6.0 | 100% |
| 4 | 1 | A | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 197.3 | 26.8 | 0.0 | 0.0 | 3.4 | 10.6 | 0.0 | 10.6 | 0% |
| 4 | 1 | B | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 105.9 | 0.0 | 6.0 | 24.0 | 2.6 | 0.0 | 6.0 | 6.0 | 100% |
| 4 | 1 | C | 5 | 100% |  0.833 |  0.833 |  0.958 |  0.958 |  0.930 | 40% | 170.0 | 23.2 | 0.0 | 0.0 | 2.6 | 6.6 | 0.0 | 6.6 | 0% |
| 4 | 1 | D | 5 | 100% |  1.000 |  1.000 |  1.000 |  1.000 |  1.000 | 100% | 111.4 | 0.0 | 6.0 | 24.6 | 2.6 | 0.0 | 6.2 | 6.2 | 100% |

### Diagnostics from T1.html and events (per cell)

html = share of episodes whose T1.html exists. trunc = share of tool.ask events whose answer hit the
token cap (fin = length), pooled over the cell. unresolved = mean count of <li> items in
<section id="unresolved">. evidence full = mean share of orders whose cited evidence includes all
four current document ids; evidence non-current = mean share of orders citing at least one
background or superseded id. adoption (M1 only) = adopted / 4 conflicts. All over delivered beats
whose T1.html exists.

| L | M | arm | n | html | trunc | unresolved | evidence full | evidence non-current | adoption |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | A | 5 | 100% | 0% | 0.0 |  1.000 |  0.000 |  0.000 |
| 1 | 1 | B | 5 | 100% | -- | 0.0 |  1.000 |  0.000 |  0.000 |
| 1 | 1 | C | 5 | 100% | 0% | 0.0 |  1.000 |  0.000 |  0.000 |
| 1 | 1 | D | 5 | 100% | -- | 0.0 |  1.000 |  0.000 |  0.000 |
| 4 | 1 | A | 5 | 100% | 7% | 0.0 |  1.000 |  0.000 |  0.000 |
| 4 | 1 | B | 5 | 100% | -- | 0.0 |  1.000 |  0.000 |  0.000 |
| 4 | 1 | C | 5 | 100% | 4% | 0.4 |  0.833 |  0.000 |  0.000 |
| 4 | 1 | D | 5 | 100% | -- | 0.0 |  1.000 |  0.000 |  0.000 |

## Contrasts per (L, M) — Q, paired by seed

S = ½[(B−A)+(D−C)] is the store effect, F = ½[(A−C)+(B−D)] the formation effect. If B−A and D−C
disagree, S averages over a real interaction; read the interaction line, not just S. Each cell is
given under both denominators: delivered-only (a seed needs all four arms delivered) and planned
(model failures enter as Q = 0; a seed with a technical loss in any arm is dropped).

### L=1 M=0
#### delivered-only
  incomplete (no seed has all four arms)

#### planned
  incomplete (no seed has all four arms)

### L=2 M=0
#### delivered-only
  incomplete (no seed has all four arms)

#### planned
  incomplete (no seed has all four arms)

### L=4 M=0
#### delivered-only
  incomplete (no seed has all four arms)

#### planned
  incomplete (no seed has all four arms)

### L=1 M=1
#### delivered-only
```
                sandbox     store
  open         1.000      1.000     A,B
  bounded      1.000      1.000     C,D
```
  S                    =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  F                    =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  B-A                  =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  D-C                  =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  (B-A)-(D-C)          =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5

#### planned
```
                sandbox     store
  open         1.000      1.000     A,B
  bounded      1.000      1.000     C,D
```
  S                    =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  F                    =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  B-A                  =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  D-C                  =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  (B-A)-(D-C)          =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5

### L=2 M=1
#### delivered-only
  incomplete (no seed has all four arms)

#### planned
  incomplete (no seed has all four arms)

### L=4 M=1
#### delivered-only
```
                sandbox     store
  open         1.000      1.000     A,B
  bounded      0.833      1.000     C,D
```
  S                    =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5
  F                    =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5
  B-A                  =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  D-C                  =  0.167   95% CI [ 0.033,  0.333]   excludes 0   n=5
  (B-A)-(D-C)          = -0.167   95% CI [-0.333, -0.033]   excludes 0   n=5

#### planned
```
                sandbox     store
  open         1.000      1.000     A,B
  bounded      0.833      1.000     C,D
```
  S                    =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5
  F                    =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5
  B-A                  =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5
  D-C                  =  0.167   95% CI [ 0.033,  0.333]   excludes 0   n=5
  (B-A)-(D-C)          = -0.167   95% CI [-0.333, -0.033]   excludes 0   n=5

### S on secondary metrics

| L | M | metric | denominator | S | 95% CI | n |
|---|---|---|---|---|---|---|
| 1 | 1 | field accuracy | delivered-only |  0.000 | [ 0.000,  0.000] | 5 |
| 4 | 1 | field accuracy | delivered-only |  0.021 | [ 0.004,  0.042] | 5 |
| 1 | 1 | field accuracy | planned |  0.000 | [ 0.000,  0.000] | 5 |
| 4 | 1 | field accuracy | planned |  0.021 | [ 0.004,  0.042] | 5 |
| 1 | 1 | requirement F1 | delivered-only |  0.000 | [ 0.000,  0.000] | 5 |
| 4 | 1 | requirement F1 | delivered-only |  0.035 | [ 0.007,  0.070] | 5 |

## Primary contrast

K = S(L=4) − S(L=1), computed per seed (a seed must have all four arms at both L) then averaged.
K > 0 alone can mean store went from worse to less bad; a quality gain at high burden needs
S(L=4) > 0 as well. Both are reported, neither is selected. Seed sets: K and "S(L=4) | K seeds" use
the seeds complete at both L=1 and L=4, so the two primaries share n; "S(L=4) all" uses every seed
complete at L=4 and "S(L=1) all" every seed complete at L=1.

### M=0 (pre-registered)
#### delivered-only
  K                    incomplete (no complete seed blocks)   [seeds complete at L=1 and L=4]
  S(L=4) | K seeds     incomplete (no complete seed blocks)   [same seeds as K]
  S(L=4) all           incomplete (no complete seed blocks)   [seeds complete at L=4]
  S(L=1) all           incomplete (no complete seed blocks)   [seeds complete at L=1]

#### planned
  K                    incomplete (no complete seed blocks)   [seeds complete at L=1 and L=4]
  S(L=4) | K seeds     incomplete (no complete seed blocks)   [same seeds as K]
  S(L=4) all           incomplete (no complete seed blocks)   [seeds complete at L=4]
  S(L=1) all           incomplete (no complete seed blocks)   [seeds complete at L=1]

#### bounds (planned denominator, missing Q filled)
  K | missing=0        incomplete (no complete seed blocks)   [0 planned seeds, 0 of 0 beats filled]
  S(L=4) | missing=0   incomplete (no complete seed blocks)   [0 planned seeds, 0 of 0 beats filled]
  K | missing=1        incomplete (no complete seed blocks)   [0 planned seeds, 0 of 0 beats filled]
  S(L=4) | missing=1   incomplete (no complete seed blocks)   [0 planned seeds, 0 of 0 beats filled]

### M=1 (secondary: conflicts)
#### delivered-only
  K                    =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5   [seeds complete at L=1 and L=4]
  S(L=4) | K seeds     =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5   [same seeds as K]
  S(L=4) all           =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5   [seeds complete at L=4]
  S(L=1) all           =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5   [seeds complete at L=1]

#### planned
  K                    =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5   [seeds complete at L=1 and L=4]
  S(L=4) | K seeds     =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5   [same seeds as K]
  S(L=4) all           =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5   [seeds complete at L=4]
  S(L=1) all           =  0.000   95% CI [ 0.000,  0.000]   spans 0   n=5   [seeds complete at L=1]

#### bounds (planned denominator, missing Q filled)
  K | missing=0        =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5   [5 planned seeds, 0 of 40 beats filled]
  S(L=4) | missing=0   =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5   [5 planned seeds, 0 of 20 beats filled]
  K | missing=1        =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5   [5 planned seeds, 0 of 40 beats filled]
  S(L=4) | missing=1   =  0.083   95% CI [ 0.017,  0.167]   excludes 0   n=5   [5 planned seeds, 0 of 20 beats filled]

### Conflicts: S(M1) − S(M0) per L

Per seed, the same world with the four historical records replaced by conflicting ones.

#### delivered-only
  L=1                  incomplete (no complete seed blocks)
  L=2                  incomplete (no complete seed blocks)
  L=4                  incomplete (no complete seed blocks)
  K(M1)-K(M0)          incomplete (no complete seed blocks)

#### planned
  L=1                  incomplete (no complete seed blocks)
  L=2                  incomplete (no complete seed blocks)
  L=4                  incomplete (no complete seed blocks)
  K(M1)-K(M0)          incomplete (no complete seed blocks)

## Wrong adoption (M1)

Share of the 4 conflicting values (one per evidence group, on four distinct orders) that the
artifact carries in the conflicted field, over delivered beats whose T1.html exists. A lower
B−A or D−C means reading the folder adopted fewer superseded values than asking its keeper.

| L | A | B | C | D | B−A | 95% CI | D−C | 95% CI | n |
|---|---|---|---|---|---|---|---|---|---|
| 1 |  0.000 |  0.000 |  0.000 |  0.000 |  0.000 | [ 0.000,  0.000] |  0.000 | [ 0.000,  0.000] | 5 |
| 2 | incomplete | | | | | | | | 0 |
| 4 |  0.000 |  0.000 |  0.000 |  0.000 |  0.000 | [ 0.000,  0.000] |  0.000 | [ 0.000,  0.000] | 5 |

## Tokens (T1, k) and the token cost of store

Whole-system tokens for the beat, all roles summed. The build receipt is the same in every arm, so
most of a difference here should be listing and reading documents versus asking for them; the
per-role table below says where it actually sits. A beat whose stats were lost in a crash is
missing, not 0.

| L | M | A | B | C | D | B−A | 95% CI | D−C | 95% CI | n |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0 | incomplete | | | | | | | | 0 |
| 2 | 0 | incomplete | | | | | | | | 0 |
| 4 | 0 | incomplete | | | | | | | | 0 |
| 1 | 1 | 58.2 | 112.3 | 51.9 | 99.9 | 54.1 | [34.6, 73.6] | 48.0 | [40.0, 56.1] | 5 |
| 2 | 1 | incomplete | | | | | | | | 0 |
| 4 | 1 | 197.3 | 105.9 | 170.0 | 111.4 | -91.5 | [-150.8, -32.1] | -58.6 | [-116.7, -0.5] | 5 |

### Tokens by role (T1, k)

Summed from the llm events of the beat by tag: req.* = requester, ask.* = responder, build.* =
builder, consult.* = builder consults (shown when non-zero). Same per-seed contrasts as above.

| L | M | role | A | B | C | D | B−A | 95% CI | D−C | 95% CI | n |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0 | requester | incomplete | | | | | | | | 0 |
| 1 | 0 | responder | incomplete | | | | | | | | 0 |
| 1 | 0 | builder | incomplete | | | | | | | | 0 |
| 2 | 0 | requester | incomplete | | | | | | | | 0 |
| 2 | 0 | responder | incomplete | | | | | | | | 0 |
| 2 | 0 | builder | incomplete | | | | | | | | 0 |
| 4 | 0 | requester | incomplete | | | | | | | | 0 |
| 4 | 0 | responder | incomplete | | | | | | | | 0 |
| 4 | 0 | builder | incomplete | | | | | | | | 0 |
| 1 | 1 | requester | 39.4 | 108.9 | 33.5 | 96.2 | 69.5 | [51.7, 87.3] | 62.7 | [55.1, 70.3] | 5 |
| 1 | 1 | responder | 15.0 | 0.0 | 14.6 | 0.0 | -15.0 | [-16.4, -13.7] | -14.6 | [-15.5, -13.9] | 5 |
| 1 | 1 | builder | 3.7 | 3.4 | 3.7 | 3.7 | -0.3 | [-1.4, 0.9] | -0.0 | [-1.2, 0.7] | 5 |
| 2 | 1 | requester | incomplete | | | | | | | | 0 |
| 2 | 1 | responder | incomplete | | | | | | | | 0 |
| 2 | 1 | builder | incomplete | | | | | | | | 0 |
| 4 | 1 | requester | 142.2 | 102.2 | 109.5 | 107.6 | -40.0 | [-88.9, 8.9] | -1.8 | [-36.4, 32.6] | 5 |
| 4 | 1 | responder | 51.6 | 0.0 | 55.8 | 0.0 | -51.6 | [-68.2, -33.6] | -55.8 | [-79.2, -32.3] | 5 |
| 4 | 1 | builder | 3.6 | 3.7 | 4.7 | 3.7 | 0.1 | [-0.5, 0.8] | -1.0 | [-2.2, 0.2] | 5 |

## Notes

- n per cell (summarised, on protocol): L1M1A=5, L1M1B=5, L1M1C=5, L1M1D=5, L4M1A=5, L4M1B=5, L4M1C=5, L4M1D=5.
- Rows are restricted to the protocol settings (E=0, k=1, seedProfile=control, edgeCost=0, relayDepth=0, dirSize=100, reputation=off, searchCap=40);
  0 row(s) were excluded for other settings, and 0 CRASHED directories never wrote a summary.
- Q is the share of the 6 orders whose balance, status and payable are all correct (assertion ids
  o{i}_balance, o{i}_status, o{i}_payable); field accuracy is the share of the 24 invoice/discount/
  accepted/paid attributes correct. Both come from the T1 beat.
- Two denominators. Delivered-only: beats that produced no artifact are excluded from the Q, field
  and F1 means and from every paired contrast (a seed needs all four arms delivered to enter a
  block). Planned: a beat whose failureKind is model (no submission, or an artifact that did not
  parse) counts as Q = 0 and field accuracy 0; a technical loss (LLM call failed, beat crashed,
  scorer threw) stays missing, and the primary contrast is bracketed with missing Q set to 0 and
  to 1 over the planned seeds. Neither denominator counts a lost beat as 0 silently; the delivery
  table above is the place to look before reading any contrast. (The delivery module's "counts a
  lost beat as F1 = 0" note describes the older analyzers, not this one.)
- Token means and token contrasts keep beats that produced no artifact when their stats survived:
  the cost was spent. A beat with tokensUnknown, or a beat.crash event, has unknown cost and is
  missing from every token mean and contrast, never 0.
- asked = distinct cards in tool.ask events plus consult.ok targets; read = distinct cards in
  tool.list and tool.read events; contacted = the union of the two. All from events.jsonl for the
  T1 beat. The beat record's own `contacted` counter is not used.
- Wrong adoption compares each conflicted order's data-invoice/discount/accepted/paid in T1.html
  with the conflicting value the superseded record carries (numbers numerically, accepted as yes/no);
  evidence coverage reads data-evidence on the same rows against the instance's document ids.
- All intervals are descriptive 95% percentile bootstraps over seeds (base cases), keeping the four
  arms of a seed together, printed only when n ≥ 5. They are not corrected for multiple
  comparisons; the pre-registered test is a paired t-test on the per-seed K_i and S_i(L=4) with
  Holm correction, which this script does not perform.
- Q and field accuracy read `failedAll` from the beat record.
- failureKind was read from the beat record.